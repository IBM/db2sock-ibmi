This is MySQL PECL extension
